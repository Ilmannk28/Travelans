export const BASE_URL = 'https://story-api.dicoding.dev/v1';
export const ACCESS_TOKEN_KEY = 'accessToken';
export const MAP_SERVICE_API_KEY = 'fLsjXXZ1yN5o8SqA5HC4'

